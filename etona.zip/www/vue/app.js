var firebaseConfig = {
    apiKey: "AIzaSyDNb8hNdOJDq5mBE6BmkWuiRK6mc1dgGEs",
    authDomain: "mobalert-955bf.firebaseapp.com",
    databaseURL: "https://mobalert-955bf.firebaseio.com",
    projectId: "mobalert-955bf",
    storageBucket: "mobalert-955bf.appspot.com",
    messagingSenderId: "625319003477",
    appId: "1:625319003477:web:e6517323d73bc4162c9bdc",
    measurementId: "G-V069QBNT2G"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

Vue.use(Vuetify);
var app = new Vue({
    el: '#app',
    vuetify: new Vuetify(),
    inject: ['theme'],
    data: {
        tab: null,
        previewed: false,
        current: {
            inccident_pic: null,
            desc: null,
            lat: null,
            long: null
        },
        fbUrls: [],
        alertoverlay: false,
        inccidentoverlay: false,
        width: 900,
        imageData: null,
        picture: null,
        uploadValue: 0,
        urlAlert: null,
        alert: {
            witness_id: null,
            witness_pic: null,
            witness_name: null,
            witness_lat: null,
            witness_long: null,
            inccident_pic: null,
            desc: null,
        },
        alerts: [],
        navigateToWaze: null,
        items: [
            { icon: 'inbox', title: 'Inbox' },
            { icon: 'star', title: 'Starred' },
            { icon: 'send', title: 'Sent mail' },
            { icon: 'drafts', title: 'Drafts' },
            { divider: true },
            { icon: 'mail', title: 'All mail' },
            { icon: 'delete', title: 'Trash' },
            { icon: 'error', title: 'Spam' },
        ],
        news: [],
        mobalertSession: {
            id: null,
            name: null,
            email: null,
            picture: null
        },
        session: {
            id: 24
        },
        fsic: {
            name: null,
            establishment: null,
            tradename: null,
            address: null,
            representative: null,
            bin: null,
            tin: null,
            phone: null,
            email: null,
            occupancy: null,
            floor: null,
            storey: null,
        },
        bfpInspections: [],
        myAttachment: [],
        position_lat: 0,
        position_long: 0,
        map: null,
        tileLayer: null,
        marker: null,
        markers: {
            lat: [
                14.609053699999997,
                14.569053699999997
            ],
            long: [
                121.1322565700001,
                121.1652565700001
            ],
        },
        circle: null,
        routing: null,
        waypoints: null,
        latLng: null,
        latLng2: null,
        navigator: null,
        my_lat: null,
        my_long: null,
        greenIcon: null,
        blueIcon: null,
        marker1: null,
        markter2: null,
        layers: [],
        isActive: false,
        occupancies: [
            "Assembly	Educational", "Health Care", "Detention and Correctional", "Residential", "Merchantile", "Businesss", "Insdustrial", "Storage", "Mixed Occupancies", "Miscellaneous"
        ],
        tips: [
            {number: 'Tips no. 1: Be fire-safety conscious', desc: 'March 1 is the start of Fire Prevention Month. Everyone is encouraged to be fire-safety conscious as fire safety is everyone’s concern.', imageTip: 'assets/img/tips/tips1.png'},
            {number: 'Tip no. 2: Keep matches out of children’s reach', desc: 'For their safety (and our homes’), matches and lighters should be placed in cupboards or drawers out of children’s reach.', imageTip: 'assets/img/tips/tips2.png'},
            {number: 'Tip no. 3: Keep lit candles away from combustible materials', desc: 'When lighting candles, make sure that they placed away from combustible materials, such as curtains, newspapers, etc.', imageTip: 'assets/img/tips/tips3.png'},
            {number: 'Tip no. 4: Do not use substandard electrical wirings and equipment', desc: 'Faulty electrical wiring is one of the main causes of fires, so make sure to use only the best type.', imageTip: 'assets/img/tips/tips4.png'},
            {number: 'Tip no. 5: Avoid using your electric fan continuously for 24 hours', desc: 'To prevent them from overheating, electric fans should be switched off after several hours of continuous use.', imageTip: 'assets/img/tips/tips5.png'},
            {number: 'Tip no. 6: Do not smoke in bed', desc: 'Lit cigarette butts can easily ignite inflammable materials, such as bed sheets and pillowcases, so avoid smoking in bed.', imageTip: 'assets/img/tips/tips6.png'},
            {number: 'Tip no. 7: Unplug and shut off electrical equipment and LPG tanks', desc: 'When leaving the house, make sure that all electrical equipment and LPG tanks are properly disconnected and shut off', imageTip: 'assets/img/tips/tips7.png'},
            {number: 'Tip no. 8: Never leave your kitchen while cooking', desc: 'Do not leave cooking food unattended. If you have to leave the kitchen, turn off the stove and take the pans and pots off the heat.', imageTip: 'assets/img/tips/tips8.png'},
            {number: 'Tip no. 9: Keep them clean and grease-free', desc: 'Your stove must be kept clean and grease-free at all times. In addition, use soapy water to check your LPG hose and connectors for any leaks.', imageTip: 'assets/img/tips/tips9.png'},
            {number: 'Tip no. 10: Avoid octopus connections', desc: 'Overloading of electrical outlets and using octopus connections and worn-out cords are some of the leading causes of household fires.', imageTip: 'assets/img/tips/tips10.png'},
            {number: 'Tip no. 11: Do not store items above the stovetop', desc: 'Space might be a big issue in today’s homes, but as much as possible, make sure to keep the space directly above your stovetop item-free.', imageTip: 'assets/img/tips/tips11.png'},
            {number: 'Tip no. 12: Idle electrical appliances must be unplugged', desc: 'When not in use, unplug.', imageTip: 'assets/img/tips/tips12.png'},
            {number: 'Tip no. 13: Keep inflammable liquids and other combustible items away from the stove', desc: 'Cooking oil, fuel, newspaper, and other combustible items must be kept away from the stove, especially when cooking.', imageTip: 'assets/img/tips/tips13.png'},
            {number: 'Tip no. 14: Make sure smoke alarms are working', desc: 'Ensure that your smoke alarms are working well and replace batteries at least every six months.', imageTip: 'assets/img/tips/tips14.png'},
            {number: 'Tip no. 15: Do not use water to put out grease fire', desc: 'When frying and your pan bursts into flames, do not douse it with water. Instead, put a lid on it or cover it with damp cloth.', imageTip: 'assets/img/tips/tips15.png'},
            {number: 'Tip no. 16: Extension cords are not meant to be used as permanent outlets', desc: 'Extension cords should only be used temporarily and not as permanent wiring devices. Also, make sure that cords are not looped around sharp objects that could cause them to fray.', imageTip: 'assets/img/tips/tips16.png'},
            {number: 'Tip no. 17: Place electric fans away from curtains', desc: 'Make sure that electric fans are placed away from curtains to avoid snagging, which may lead to fire.', imageTip: 'assets/img/tips/tips17.png'},
            {number: 'Tip no. 18: Do not leave an electric fan switched on when it’s not rotating', desc: 'Clean and oil them regularly to make they’re working properly.', imageTip: 'assets/img/tips/tips18.png'},
            {number: 'Tip no. 19: Defective appliances must not be used and should be fixed immediately', desc: 'Do not use defective appliances as they may lead to overheated wiring.', imageTip: 'assets/img/tips/tips19.png'},
            {number: 'Tip no. 20: Unplug your flat iron and rice cooker after use', desc: 'Take extra care when using your flat iron or rice cooker, and unplug them immediately after use.', imageTip: 'assets/img/tips/tips20.png'},
            {number: 'Tip no. 21: Put out any lit candle before going to sleep', desc: 'It is common in Filipino homes to light candles in altars, but to be safe, make sure to put out lit candles before going to sleep.', imageTip: 'assets/img/tips/tips21.png'},
            {number: 'Tip no. 22: Place a lit candle on a candleholder', desc: 'If you have none, place it in the middle of a basin partly filled with water and keep it away from combustible materials.', imageTip: 'assets/img/tips/tips22.png'},
            {number: 'Tip no. 23: Use smoke detectors', desc: 'Install smoke detectors in bedrooms, the kitchen, and living areas. They sound off an alert when fire is still in a controllable state.', imageTip: 'assets/img/tips/tips23.png'},
            {number: 'Tip no. 24: Keep a fire extinguisher', desc: 'If possible, have an ABC type of fire extinguisher in your kitchen and workshop areas—and take time to learn how to use it. A stands for light materials such as paper, plastic, wood, leaves, etc.; B stands for flammable liquids like kerosene, paint, solvents, etc.; and C stands for energized electrical equipment such as plugged appliances and tools.', imageTip: 'assets/img/tips/tips24.png'},
            {number: 'Tip no. 25: Stay away from inflammable liquids', desc: 'Do not store large quantities of inflammable liquids in the house and basement areas.', imageTip: 'assets/img/tips/tips25.png'},
            {number: 'Tip no. 26: Dispose of combustible items and trash', desc: 'Oily rags, newspaper, and other trash must be disposed in a safe waste bag or container.', imageTip: 'assets/img/tips/tips26.png'},
            {number: 'Tip no. 27: Clean up spilled oil and grease from vehicles promptly', desc: 'Grease and spilled oil from vehicles must be cleaned promptly.', imageTip: 'assets/img/tips/tips27.png'},
            {number: 'Tip no. 28: Plug your power tools straight to the wall socket', desc: 'When using power tools, make sure plug them directly to a wall socket, or use only heavy-duty extension cords when needed.', imageTip: 'assets/img/tips/tips28.png'},
            {number: 'Tip no. 29: Keep your garage well-ventilated', desc: 'As garages are place where combustible items are normally store, make sure they are well-ventilated to avoid buildup of fumes and heat from tools.', imageTip: 'assets/img/tips/tips29.png'},
            {number: 'Tip no. 30: Keep your place clean at all times', desc: 'Dispose dry leaves, cobwebs, loose paper, and other combustible debris at all times.', imageTip: 'assets/img/tips/tips30.png'},
            {number: 'Tip no. 31: Today is the culmination of Fire Prevention Month 2017', desc: 'Let us all be fire-safety conscious at all times and make every day a fire prevention day.', imageTip: 'assets/img/tips/tips31.png'},
        ],
        sheet: false,
        alertLen: null,
        alertLoader: null,
        newsLoader: null,
        tipsLoader: null
    },
    mounted() {
        this.display_news();
        this.getLocation();

        setTimeout(() => {
            this.alertLoader = this.alerts,
            this.newsLoader = this.news
            this.tipsLoader = this.tips
        }, 4000)

      /*   setTimeout(() => {
            this.newsLoader = this.news
        }, 4000)
 */
        
    },
    methods: {
        sendSms(name, desc, lat, long){
            var sms = {
                smsName: name,
                smsDesc: desc,
                smsLat: lat,
                smsLong: long
            }
            var formData = app.toFormData(sms);
            axios.post('controller/send_sms.php', formData).then(response => {
              if (response.data.error) {
                console.log(response.data.message);
              } else {
               /*  this.display_inspection();
                Swal.fire(
                  'Record Added!',
                  'You succesfully add the record!',
                  'success'
                )
                $('#AddInspectionRecord').modal('hide');   
                app.snackbar_saved = true */
                sms = {}
              }
            })
        },
        afterEnterName(){
          $("#alertName").modal("hide");
          $("#alertDesc").focus();
        },
        showNews(url){
            window.open(url)
        },
        chooseImage(){
            this.$refs.viewImage.click()
        },
        previewImage(event) {
            this.uploadValue=0;
            this.picture=null;
            this.imageData=event.target.files[0];

            const file = event.target.files[0];
            this.urlAlert = URL.createObjectURL(file);
            
            $('#cameraInput').css('display', 'none');
            $('#cameraCancel').css('display', 'none');
            $('#cameraLabel').css('display', 'none');

            this.previewed = true
            $("#alertName").modal("show");
        },
        onUpload(){
            this.picture=null;
            const storageRef = firebase.storage().ref(this.imageData.name).put(this.imageData);
            storageRef.on('state_changed', snapshot => {
                this.uploadValue=(snapshot.bytesTransferred/snapshot.totalBytes)*100;
                }, error =>{ console.log(error.message)},
                () => {this.uploadValue=100;
                storageRef.snapshot.ref.getDownloadURL().then((url) => {
                    this.picture = url;
                    this.alert.inccident_pic = url;


                    var alertFire = {
                        id: counter,
                        witness_name: this.alert.witness_name,
                        witness_lat: this.alert.witness_lat,
                        witness_long: this.alert.witness_long,
                        inccident_pic: url,
                        inccident_time: time,
                        desc: this.alert.desc,  
                    }

                    this.sendSms(this.alert.witness_name,  this.alert.desc, this.alert.witness_lat, this.alert.witness_long)

                    this.alertoverlay = false
                    this.alert.desc = null
                    this.alert.inccident_pic = null
                    this.picture = null
                    this.urlAlert = null
  
                    console.log(alertFire)

                    $('#cameraInput').css('display', 'block');
                    $('#cameraCancel').css('display', 'block');
                    $('#cameraLabel').css('display', 'block');

                    this.uploadValue=0; // set 0 the value of progressbar in uploading image

                    var alertdb = firebase.database().ref("inccidents/"); // TO CALL A LIST IN  INCCIDENT ALERTS
                    var alertsdb = [];

                    alertdb.on("child_added", function(data){
                        var alertValue = data.val();
                    
                        alertsdb.push(alertValue);
                    });
                    this.alerts= alertsdb;

                    this.alertLen = this.alerts.length

        
                    let db = firebase.database().ref("inccidents/" + counter);
                    db.set(alertFire);
        /*             console.log($("#session_id").val())
                    console.log($("#session_picture").val())
                    console.log($("#session_name").val())
                    console.log(this.alert.witness_lat)
                    console.log(this.alert.witness_long)
                    console.log(this.alert.inccident_pic)
                    console.log(time)
                    console.log(this.alert.desc) */
                    swal(
                        "Alert Inccident Sent!",
                        "Thankyou for your reporting. Please wait for respond of the BFP on your inccident location", 
                        "success"
                    );

                    

                });
                }
            );
            var today = new Date();
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds() + ' ' + today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            let dateId = new Date();
            let timeId = dateId.getTime();
            let counter = timeId;
        },
        addFsic() {
            var today = new Date();
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds() + ' ' + today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            let dateId = new Date();
            let timeId = dateId.getTime();
            let counter = timeId;
            var fsicFire = {
                id: counter,
                name: this.fsic.name,
                establishment: this.fsic.establishment,
                tradename: this.fsic.tradename,
                address: this.fsic.address,
                representative: this.fsic.representative,
                bin: this.fsic.bin,
                tin: this.fsic.tin,
                phone: this.fsic.phone,
                email: this.fsic.email,
                occupancy: this.fsic.occupancy,
                floor: this.fsic.floor,
                storey: this.fsic.storey,
                dateTime: time
            }

            let db = firebase.database().ref("fsic/" + counter);
            db.set(fsicFire);
            this.fsic = {}

            console.log(fsicFire)
            swal(
                "FSIC Application Submited!",
                "Please wait for your Attached Documentary Requirements that will send from BFP", 
                "success"
            );
        },
        display_news() {
            axios.get('https://newsapi.org/v2/top-headlines?country=ph&apiKey=c948915906cf4ef1a44f02fe585efe08').then(response => {
                this.news = response.data.articles
                console.log(this.news)
            })
        },
        getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(this.showPosition, null, {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                });
            } else {
                alert("GEOLOCATION NOT SUPPORTED")
            }

            /*   this.position_lat = position.coords.latitude
              this.position_long = position.coords.longitude */
        },
        showPosition(position) {
            app.position_lat = position.coords.latitude
            app.position_long = position.coords.longitude

            this.alert.witness_lat = position.coords.latitude
            this.alert.witness_long = position.coords.longitude

            this.map = L.map('alertMap', {
                minZoom: 4,
                maxZoom: 18,
            });

            this.map.setView([position.coords.latitude, position.coords.longitude], 14);
            /* 
                    this.map = L.map('mapid').setView([position.coords.latitude, position.coords.longitude], 4);
            */

            this.tileLayer = L.tileLayer(
                'https://api.mapbox.com/styles/v1/wazaskiller24/ck92u4c132ip71iqj4wqr1ulp/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1Ijoid2F6YXNraWxsZXIyNCIsImEiOiJjazkydGcyYngwMXA1M21wMTM5eDN0YXdnIn0.TAbTjQWyDwVNlqhL0_h0rg',
                {
                    maxZoom: 20,
                    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
                    id: 'mapbox/streets-v11',
                    tileSize: 512,
                    zoomOffset: -1,
                    accessToken: 'pk.eyJ1Ijoid2F6YXNraWxsZXIyNCIsImEiOiJjazkydGcyYngwMXA1M21wMTM5eDN0YXdnIn0.TAbTjQWyDwVNlqhL0_h0rg',
                }
            );
            this.tileLayer.addTo(this.map);


            this.greenIcon = L.icon({
                iconUrl: '../assets/img/icon/gif/pin.gif',
                /*  shadowUrl: 'leaf-shadow.png', */

                iconSize: [75, 95], // size of the icon
                shadowSize: [60, 60], // size of the shadow
                iconAnchor: [22, 94], // point of the icon which will correspond to marker's location
                shadowAnchor: [4, 62],  // the same for the shadow
                popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
            })

            //this.blueIcon = L.icon({
            //iconUrl: 'assets/icon/MOBALERT_LOGO.png',
            /*  shadowUrl: 'leaf-shadow.png', */

            //iconSize: [55, 55], // size of the icon
            //shadowSize: [60, 60], // size of the shadow
            //iconAnchor: [22, 94], // point of the icon which will correspond to marker's location
            //shadowAnchor: [4, 62],  // the same for the shadow
            //popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
            //});


            /* 
                    this.markers = [
                        L.marker([14.609053699999997, 121.1322565700001], { icon: this.greenIcon }),
                        L.marker([14.609053699999534, 121.1265650060002], { icon: this.greenIcon }),
                        L.marker([14.609053699999991, 121.1828565000007], { icon: this.greenIcon }),
                        L.marker([14.609053699999123, 121.1025565210004], { icon: this.greenIcon }) 
                    ] */

            var x;
            /*             var lat = 0;
                    var long = 0; */

            for (x = 0; x < 2; x++) {
                L.marker([this.markers.lat[x], this.markers.long[x]], { icon: this.greenIcon }).addTo(this.map).bindPopup('<div><img src="../assets/img/faces/avatar.jpg" style="width: 40px; border-radius: 50%"></img><span>Alvin Laroya</span><br><button class="btn btn-primary" @click="alert(1)">Navigate</button></div>').openPopup();
            }

            /*     this.routing = L.Routing.control({
                    waypoints: [
                      L.latLng(position.coords.latitude, position.coords.longitude),
                      L.latLng(lat, long)
                    ]
                  }).addTo(this.map); */
            /* 
                      this.routing = L.Routing.control({
                        waypoints: [
                          L.latLng(position.coords.latitude, position.coords.longitude),
                          L.latLng(14.609053699999997, 121.1322565700001)
                        ]
                      }).addTo(this.map); */
        },
        myLocation() {
            this.map.setView([map.position_lat, map.position_long], 17);
        },
        showInccident(alert){
            this.inccidentoverlay = true
            this.navigateToWaze = 'https://waze.com/ul?ll='+alert.witness_lat+','+alert.witness_long+'&navigate=yes'
            this.current.inccident_pic = alert.inccident_pic
            this.current.desc = alert.desc
            this.current.lat = alert.witness_lat
            this.current.long = alert.witness_long
        },
        closeInccidentOverlay(){
            this.inccidentoverlay = false
        },
        toFormData(obj) {
            var fd = new FormData();
            for (var i in obj) {
              fd.append(i, obj[i]);
            }
            return fd;
        }
    },
    created(){
        var fsicdb = firebase.database().ref("applicant/");
        var fsicsdb = [];

        fsicdb.on("child_added", function(data){
            var fsicValue = data.val();
            console.log(fsicValue);
            fsicsdb.push(fsicValue);
            
        });
        this.myAttachment = fsicsdb;




        var alertdb = firebase.database().ref("inccidents/");
        var alertsdb = [];

        alertdb.on("child_added", function(data){
            var alertValue = data.val();
          
            alertsdb.push(alertValue);
        });
        this.alerts= alertsdb;
        

        this.alertLen = this.alerts.length

    }
})