<?php

/* require_once __DIR__ . '/../config.php'; */
require_once '../vendor/autoload.php';


$name = $_POST['smsName'];
$desc = $_POST['smsDesc'];
$lat = $_POST['smsLat'];
$long = $_POST['smsLong'];

$text = $name. ": " .$desc. ". To respond using your waze up please visit https://waze.com/ul?ll=".$lat.",".$long."&navigate=yes";

$basic  = new \Nexmo\Client\Credentials\Basic('89545133', 'us4upGYMMahTgl3l');
$client = new \Nexmo\Client($basic);

try {
    $message = $client->message()->send([
        'to' => +639381453259,
        'from' => $name,
        'text' => $text
    ]);
    $response = $message->getResponseData();

    if($response['messages'][0]['status'] == 0) {
        echo "The message was sent successfully\n";
    } else {
        echo "The message failed with status: " . $response['messages'][0]['status'] . "\n";
    }
} catch (Exception $e) {
    echo "The message was not sent. Error: " . $e->getMessage() . "\n";
}


echo "name: " .$name. "<br>desc:" .$desc. "<br>lat:" .$lat. "<br>long" .$long;