const accountSid = 'AC66485aceb5680d868a2ad6d29205dc89';
const authToken = '4516556f572130a03b1706c052e264e4';
const client = require('twilio')(accountSid, authToken);

client.messages
.create({
    body: 'Mahal ka ni Allora Tiwala lang',
    from: '+12054795724',
    to: '+639381453259'
})
.then(message => console.log(message.sid));